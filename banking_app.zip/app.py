from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)
DB_FILE = "bank.db"

def query_db(query, args=(), one=False):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute(query, args)
    rv = cur.fetchall()
    conn.commit()
    conn.close()
    return (rv[0] if rv else None) if one else rv

# Create (POST)
@app.route("/accounts", methods=["POST"])
def create_account():
    data = request.json
    try:
        query_db("INSERT INTO accounts (account_no, name, balance) VALUES (?, ?, ?)",
                 (data["account_no"], data["name"], data["balance"]))
        return jsonify({"message": "Account created"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Read (GET all)
@app.route("/accounts", methods=["GET"])
def get_accounts():
    rows = query_db("SELECT * FROM accounts")
    accounts = [{"account_no": r[0], "name": r[1], "balance": r[2]} for r in rows]
    return jsonify(accounts)

# Read (GET by account_no)
@app.route("/accounts/<int:account_no>", methods=["GET"])
def get_account(account_no):
    row = query_db("SELECT * FROM accounts WHERE account_no=?", (account_no,), one=True)
    if row:
        return jsonify({"account_no": row[0], "name": row[1], "balance": row[2]})
    return jsonify({"error": "Account not found"}), 404

# Update (PUT)
@app.route("/accounts/<int:account_no>", methods=["PUT"])
def update_account(account_no):
    data = request.json
    query_db("UPDATE accounts SET name=?, balance=? WHERE account_no=?",
             (data["name"], data["balance"], account_no))
    return jsonify({"message": "Account updated"})

# Delete (DELETE)
@app.route("/accounts/<int:account_no>", methods=["DELETE"])
def delete_account(account_no):
    query_db("DELETE FROM accounts WHERE account_no=?", (account_no,))
    return jsonify({"message": "Account deleted"})

if __name__ == "__main__":
    app.run(debug=True)
